# Heroku

This plugin provides completion for the [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli).

To use it add heroku to the plugins array in your zshrc file:

```bash
plugins=(... heroku)
```
